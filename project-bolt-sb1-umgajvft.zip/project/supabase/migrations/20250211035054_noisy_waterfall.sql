/*
  # Crear tablas para el sistema de chat

  1. Nuevas Tablas
    - `chats`: Almacena información de chats individuales y grupales
    - `chat_participants`: Gestiona los participantes de cada chat
    - `messages`: Almacena los mensajes de los chats

  2. Seguridad
    - Habilitar RLS en todas las tablas
    - Políticas para asegurar que los usuarios solo accedan a sus chats y mensajes
*/

-- Tabla de chats
CREATE TABLE IF NOT EXISTS chats (
    id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
    type text NOT NULL CHECK (type IN ('individual', 'group')),
    name text, -- Para grupos
    participants uuid[] NOT NULL,
    last_message jsonb,
    created_at timestamptz NOT NULL DEFAULT now(),
    updated_at timestamptz NOT NULL DEFAULT now()
);

-- Tabla de participantes de chat
CREATE TABLE IF NOT EXISTS chat_participants (
    chat_id uuid REFERENCES chats(id) ON DELETE CASCADE,
    user_id uuid REFERENCES auth.users(id) ON DELETE CASCADE,
    joined_at timestamptz NOT NULL DEFAULT now(),
    last_read timestamptz NOT NULL DEFAULT now(),
    PRIMARY KEY (chat_id, user_id)
);

-- Tabla de mensajes
CREATE TABLE IF NOT EXISTS messages (
    id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
    chat_id uuid REFERENCES chats(id) ON DELETE CASCADE,
    sender_id uuid REFERENCES auth.users(id) ON DELETE SET NULL,
    content text NOT NULL,
    created_at timestamptz NOT NULL DEFAULT now(),
    read_by uuid[] NOT NULL DEFAULT ARRAY[]::uuid[]
);

-- Habilitar RLS
ALTER TABLE chats ENABLE ROW LEVEL SECURITY;
ALTER TABLE chat_participants ENABLE ROW LEVEL SECURITY;
ALTER TABLE messages ENABLE ROW LEVEL SECURITY;

-- Políticas para chats
CREATE POLICY "Users can view their chats"
    ON chats
    FOR SELECT
    TO authenticated
    USING (auth.uid() = ANY(participants));

CREATE POLICY "Users can create chats"
    ON chats
    FOR INSERT
    TO authenticated
    WITH CHECK (auth.uid() = ANY(participants));

-- Políticas para participantes
CREATE POLICY "Users can view chat participants"
    ON chat_participants
    FOR SELECT
    TO authenticated
    USING (EXISTS (
        SELECT 1 FROM chats
        WHERE id = chat_id
        AND auth.uid() = ANY(participants)
    ));

CREATE POLICY "Users can manage their participation"
    ON chat_participants
    FOR ALL
    TO authenticated
    USING (user_id = auth.uid());

-- Políticas para mensajes
CREATE POLICY "Users can view messages in their chats"
    ON messages
    FOR SELECT
    TO authenticated
    USING (EXISTS (
        SELECT 1 FROM chats
        WHERE id = chat_id
        AND auth.uid() = ANY(participants)
    ));

CREATE POLICY "Users can send messages to their chats"
    ON messages
    FOR INSERT
    TO authenticated
    WITH CHECK (
        sender_id = auth.uid()
        AND EXISTS (
            SELECT 1 FROM chats
            WHERE id = chat_id
            AND auth.uid() = ANY(participants)
        )
    );