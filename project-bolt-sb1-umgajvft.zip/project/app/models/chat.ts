export interface Message {
    id: string;
    chatId: string;
    senderId: string;
    content: string;
    createdAt: Date;
    readBy: string[];
}

export interface Chat {
    id: string;
    type: 'individual' | 'group';
    name?: string; // Para grupos
    participants: string[];
    lastMessage?: Message;
    createdAt: Date;
    updatedAt: Date;
}

export interface ChatParticipant {
    chatId: string;
    userId: string;
    joinedAt: Date;
    lastRead: Date;
}