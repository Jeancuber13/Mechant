export interface Profile {
    id: string;
    userId: string;
    fullName: string;
    phone: string;
    email: string;
    position: string;
    yearsExperience: number;
    certifications: string[];
    currentPrice: number;
    isAvailable: boolean;
    profileImage?: string;
    rating: number;
    location: string;
    languages: string[];
}

export interface Experience {
    id: string;
    profileId: string;
    vesselName: string;
    vesselType: string;
    position: string;
    startDate: Date;
    endDate: Date;
    description: string;
    company: string;
    route: string;
}

export interface Bid {
    id: string;
    profileId: string;
    bidderId: string;
    amount: number;
    status: 'pending' | 'accepted' | 'rejected';
    message: string;
    createdAt: Date;
}

export interface Certificate {
    id: string;
    profileId: string;
    name: string;
    issueDate: Date;
    expiryDate: Date;
    issuingAuthority: string;
    documentUrl: string;
}