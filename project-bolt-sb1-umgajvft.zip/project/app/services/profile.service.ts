import { supabase } from './supabase';
import type { Profile, Experience, Bid, Certificate } from '../models/profile';

export class ProfileService {
    async createProfile(profile: Partial<Profile>) {
        const { data, error } = await supabase
            .from('profiles')
            .insert(profile)
            .select()
            .single();
            
        if (error) throw error;
        return data;
    }

    async getProfile(id: string) {
        const { data, error } = await supabase
            .from('profiles')
            .select(`
                *,
                experiences (*),
                certificates (*),
                bids (*)
            `)
            .eq('id', id)
            .single();
            
        if (error) throw error;
        return data;
    }

    async updateProfile(id: string, updates: Partial<Profile>) {
        const { data, error } = await supabase
            .from('profiles')
            .update(updates)
            .eq('id', id)
            .select()
            .single();
            
        if (error) throw error;
        return data;
    }

    async createBid(bid: Partial<Bid>) {
        const { data, error } = await supabase
            .from('bids')
            .insert(bid)
            .select()
            .single();
            
        if (error) throw error;
        return data;
    }

    async addExperience(experience: Partial<Experience>) {
        const { data, error } = await supabase
            .from('experiences')
            .insert(experience)
            .select()
            .single();
            
        if (error) throw error;
        return data;
    }

    async uploadCertificate(certificate: Partial<Certificate>, file: any) {
        const { data: fileData, error: fileError } = await supabase
            .storage
            .from('certificates')
            .upload(`${certificate.profileId}/${file.name}`, file);
            
        if (fileError) throw fileError;

        const { data, error } = await supabase
            .from('certificates')
            .insert({
                ...certificate,
                documentUrl: fileData.path
            })
            .select()
            .single();
            
        if (error) throw error;
        return data;
    }
}