import { Observable } from '@nativescript/core';
import { supabase } from './supabase';
import type { Chat, Message, ChatParticipant } from '../models/chat';

export class ChatService extends Observable {
    private currentUserId: string;
    private subscriptions: any[] = [];

    constructor(userId: string) {
        super();
        this.currentUserId = userId;
        this.setupRealTimeSubscriptions();
    }

    private setupRealTimeSubscriptions() {
        const messageSubscription = supabase
            .channel('public:messages')
            .on('INSERT', payload => {
                const message = payload.new as Message;
                if (this.isParticipant(message.chatId)) {
                    this.notifyNewMessage(message);
                }
            })
            .subscribe();

        const chatSubscription = supabase
            .channel('public:chats')
            .on('UPDATE', payload => {
                this.notify({
                    eventName: 'chatUpdated',
                    object: this,
                    chat: payload.new
                });
            })
            .subscribe();

        this.subscriptions.push(messageSubscription, chatSubscription);
    }

    public cleanup() {
        this.subscriptions.forEach(subscription => {
            subscription.unsubscribe();
        });
        this.subscriptions = [];
    }

    private async isParticipant(chatId: string): Promise<boolean> {
        try {
            const { data } = await supabase
                .from('chat_participants')
                .select('userId')
                .eq('chatId', chatId)
                .eq('userId', this.currentUserId)
                .single();
            return !!data;
        } catch {
            return false;
        }
    }

    private async notifyNewMessage(message: Message) {
        this.notify({
            eventName: 'newMessage',
            object: this,
            message
        });
    }

    async getChat(chatId: string): Promise<Chat | null> {
        const { data, error } = await supabase
            .from('chats')
            .select(`
                *,
                participants:chat_participants(userId, lastRead),
                messages:messages(*)
            `)
            .eq('id', chatId)
            .single();

        if (error) throw error;
        return data;
    }

    async createIndividualChat(otherUserId: string): Promise<Chat> {
        // Verificar si ya existe un chat individual
        const { data: existingChat } = await supabase
            .from('chats')
            .select('*')
            .eq('type', 'individual')
            .contains('participants', [this.currentUserId, otherUserId])
            .single();

        if (existingChat) return existingChat;

        // Crear nuevo chat en una transacción
        const { data: chat, error: chatError } = await supabase
            .from('chats')
            .insert({
                type: 'individual',
                participants: [this.currentUserId, otherUserId],
                createdAt: new Date().toISOString(),
                updatedAt: new Date().toISOString()
            })
            .select()
            .single();

        if (chatError) throw chatError;

        // Crear participantes
        const participants = [this.currentUserId, otherUserId].map(userId => ({
            chatId: chat.id,
            userId,
            joinedAt: new Date().toISOString(),
            lastRead: new Date().toISOString()
        }));

        const { error: participantsError } = await supabase
            .from('chat_participants')
            .insert(participants);

        if (participantsError) throw participantsError;

        return chat;
    }

    async createGroupChat(name: string, participantIds: string[]): Promise<Chat> {
        const allParticipants = [...new Set([...participantIds, this.currentUserId])];

        const { data: chat, error: chatError } = await supabase
            .from('chats')
            .insert({
                type: 'group',
                name,
                participants: allParticipants,
                createdAt: new Date().toISOString(),
                updatedAt: new Date().toISOString()
            })
            .select()
            .single();

        if (chatError) throw chatError;

        const participants = allParticipants.map(userId => ({
            chatId: chat.id,
            userId,
            joinedAt: new Date().toISOString(),
            lastRead: new Date().toISOString()
        }));

        const { error: participantsError } = await supabase
            .from('chat_participants')
            .insert(participants);

        if (participantsError) throw participantsError;

        return chat;
    }

    async sendMessage(chatId: string, content: string): Promise<Message> {
        const now = new Date().toISOString();

        const { data: message, error: messageError } = await supabase
            .from('messages')
            .insert({
                chatId,
                senderId: this.currentUserId,
                content,
                createdAt: now,
                readBy: [this.currentUserId]
            })
            .select()
            .single();

        if (messageError) throw messageError;

        const { error: chatError } = await supabase
            .from('chats')
            .update({
                lastMessage: message,
                updatedAt: now
            })
            .eq('id', chatId);

        if (chatError) throw chatError;

        return message;
    }

    async getChats(): Promise<Chat[]> {
        const { data: chats, error } = await supabase
            .from('chats')
            .select(`
                *,
                participants:chat_participants(userId, lastRead),
                messages:messages(*)
            `)
            .contains('participants', [this.currentUserId])
            .order('updatedAt', { ascending: false });

        if (error) throw error;
        return chats;
    }

    async getChatMessages(chatId: string, limit = 50): Promise<Message[]> {
        const { data: messages, error } = await supabase
            .from('messages')
            .select('*')
            .eq('chatId', chatId)
            .order('createdAt', { ascending: false })
            .limit(limit);

        if (error) throw error;
        return messages;
    }

    async markAsRead(chatId: string): Promise<void> {
        const now = new Date().toISOString();
        
        const { error } = await supabase
            .from('chat_participants')
            .update({ lastRead: now })
            .eq('chatId', chatId)
            .eq('userId', this.currentUserId);

        if (error) throw error;
    }
}