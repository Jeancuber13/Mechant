import { Observable } from '@nativescript/core';
import { supabase } from './supabase';

class AuthService extends Observable {
    private _currentUser = null;

    constructor() {
        super();
        this.initializeAuth();
    }

    private async initializeAuth() {
        const { data: { session } } = await supabase.auth.getSession();
        if (session?.user) {
            this._currentUser = session.user;
        }

        supabase.auth.onAuthStateChange((event, session) => {
            this._currentUser = session?.user || null;
            this.notifyPropertyChange('currentUser', this._currentUser);
        });
    }

    get currentUser() {
        return this._currentUser;
    }

    async signUp(email: string, password: string) {
        if (!email || !password) {
            throw new Error('Email y contraseña son requeridos');
        }

        const { data, error } = await supabase.auth.signUp({
            email,
            password
        });
        
        if (error) throw error;
        return data;
    }

    async signIn(email: string, password: string) {
        if (!email || !password) {
            throw new Error('Email y contraseña son requeridos');
        }

        const { data, error } = await supabase.auth.signInWithPassword({
            email,
            password
        });
        
        if (error) throw error;
        this._currentUser = data.user;
        return data;
    }

    async signOut() {
        const { error } = await supabase.auth.signOut();
        if (error) throw error;
        this._currentUser = null;
    }

    isAuthenticated() {
        return this._currentUser !== null;
    }
}

export const authService = new AuthService();