import { Observable } from '@nativescript/core';
import { ChatService } from '../../services/chat.service';
import { Message, Chat } from '../../models/chat';
import { navigate } from '@nativescript/core/ui/frame';

export class ChatViewModel extends Observable {
    private chatService: ChatService;
    private _messages: Message[] = [];
    private _chat: Chat;
    messageText: string = '';

    constructor(private chatId: string, userId: string) {
        super();
        this.chatService = new ChatService(userId);
        this.loadChat();
        this.setupMessageListener();
    }

    private async loadChat() {
        try {
            // Primero obtenemos el chat para asegurar que existe
            const chat = await this.chatService.getChat(this.chatId);
            if (!chat) {
                throw new Error('Chat no encontrado');
            }
            
            const messages = await this.chatService.getChatMessages(this.chatId);
            
            this._chat = chat;
            this._messages = this.processMessages(messages);
            
            this.set('chat', this._chat);
            this.set('messages', this._messages);
            this.set('chatName', this.getChatName());
            
            await this.chatService.markAsRead(this.chatId);
        } catch (error) {
            console.error('Error loading chat:', error);
            alert('Error al cargar el chat');
            navigate({
                moduleName: 'views/chat/chat-list-page',
                clearHistory: true
            });
        }
    }

    private setupMessageListener() {
        this.chatService.on('newMessage', (args) => {
            const message = args.message;
            if (message.chatId === this.chatId) {
                this.addMessage(message);
                this.chatService.markAsRead(this.chatId).catch(console.error);
            }
        });
    }

    private processMessages(messages: Message[]) {
        return messages.map(message => ({
            ...message,
            isCurrentUser: message.senderId === this.chatService.currentUserId,
            time: this.formatTime(message.createdAt)
        })).sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime());
    }

    async onSendMessage() {
        if (!this.messageText?.trim()) return;

        const messageText = this.messageText.trim();
        this.set('messageText', ''); // Limpiar inmediatamente para mejor UX

        try {
            const message = await this.chatService.sendMessage(
                this.chatId,
                messageText
            );
            this.addMessage(message);
        } catch (error) {
            console.error('Error sending message:', error);
            alert('Error al enviar el mensaje');
            this.set('messageText', messageText); // Restaurar el mensaje si falló
        }
    }

    private addMessage(message: Message) {
        const processedMessage = this.processMessages([message])[0];
        this._messages = [processedMessage, ...this._messages];
        this.set('messages', [...this._messages]);
    }

    onChatInfo() {
        if (this._chat?.type === 'group') {
            navigate({
                moduleName: 'views/chat/chat-info-page',
                context: { chatId: this.chatId }
            });
        }
    }

    private formatTime(date: Date | string): string {
        if (!date) return '';
        const messageDate = new Date(date);
        const now = new Date();
        
        if (messageDate.toDateString() === now.toDateString()) {
            return messageDate.toLocaleTimeString([], { 
                hour: '2-digit', 
                minute: '2-digit' 
            });
        }
        return messageDate.toLocaleDateString();
    }

    private getChatName(): string {
        if (!this._chat) return 'Chat';
        if (this._chat.type === 'group') return this._chat.name || 'Grupo';
        return this._chat.participantNames || 'Chat';
    }
}