import { Observable } from '@nativescript/core';
import { ChatService } from '../../services/chat.service';
import { Chat } from '../../models/chat';
import { navigate } from '@nativescript/core/ui/frame';
import { authService } from '../../services/auth.service';

export class ChatListViewModel extends Observable {
    private chatService: ChatService;
    private _chats: Chat[] = [];
    isLoading = false;

    constructor() {
        super();
        // Usar el ID del usuario autenticado
        const userId = authService.currentUser?.id;
        if (!userId) {
            navigate({
                moduleName: 'views/auth/login-page',
                clearHistory: true
            });
            return;
        }
        this.chatService = new ChatService(userId);
        this.loadChats();
        this.setupMessageListener();
    }

    private async loadChats() {
        this.set('isLoading', true);
        try {
            const chats = await this.chatService.getChats();
            this._chats = this.processChats(chats);
            this.set('chats', this._chats);
        } catch (error) {
            console.error('Error loading chats:', error);
            alert('Error al cargar los chats');
        } finally {
            this.set('isLoading', false);
        }
    }

    private processChats(chats: Chat[]) {
        return chats.map(chat => ({
            ...chat,
            lastMessageTime: this.formatTime(chat.lastMessage?.createdAt),
            unreadCount: this.calculateUnreadCount(chat),
            participantNames: this.getParticipantNames(chat)
        }));
    }

    private setupMessageListener() {
        this.chatService.on('newMessage', (args) => {
            const message = args.message;
            this.updateChatWithNewMessage(message);
        });
    }

    private updateChatWithNewMessage(message: any) {
        const chatIndex = this._chats.findIndex(c => c.id === message.chatId);
        if (chatIndex > -1) {
            const updatedChat = {
                ...this._chats[chatIndex],
                lastMessage: message,
                lastMessageTime: this.formatTime(message.createdAt),
                unreadCount: this._chats[chatIndex].unreadCount + 1
            };
            this._chats.splice(chatIndex, 1);
            this._chats.unshift(updatedChat);
            this.set('chats', [...this._chats]);
        }
    }

    onChatTap(args: any) {
        const chat = args.object.bindingContext;
        navigate({
            moduleName: 'views/chat/chat-page',
            context: { chatId: chat.id }
        });
    }

    onNewChat() {
        navigate({
            moduleName: 'views/chat/new-chat-page'
        });
    }

    private formatTime(date: Date | string): string {
        if (!date) return '';
        const messageDate = new Date(date);
        const now = new Date();
        
        if (messageDate.toDateString() === now.toDateString()) {
            return messageDate.toLocaleTimeString([], { 
                hour: '2-digit', 
                minute: '2-digit' 
            });
        }
        return messageDate.toLocaleDateString();
    }

    private calculateUnreadCount(chat: Chat): number {
        if (!chat.participants || !chat.messages) return 0;
        
        const participant = chat.participants.find(p => 
            p.userId === this.chatService.currentUserId
        );
        if (!participant?.lastRead) return 0;
        
        const lastReadDate = new Date(participant.lastRead);
        return chat.messages.filter(m => 
            new Date(m.createdAt) > lastReadDate
        ).length;
    }

    private getParticipantNames(chat: Chat): string {
        if (chat.type === 'group') return chat.name || 'Grupo';
        
        // Filtrar el usuario actual y mostrar los nombres de los otros participantes
        const otherParticipants = chat.participants?.filter(
            p => p.userId !== this.chatService.currentUserId
        ) || [];
        
        return otherParticipants.map(p => p.userId).join(', ') || 'Chat';
    }

    // Importante: Limpiar los listeners cuando se destruye el viewmodel
    destroy() {
        this.chatService.cleanup();
    }
}