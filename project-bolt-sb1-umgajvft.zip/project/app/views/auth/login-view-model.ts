import { Observable } from '@nativescript/core';
import { authService } from '../../services/auth.service';
import { navigate } from '@nativescript/core/ui/frame';

export class LoginViewModel extends Observable {
    email: string = '';
    password: string = '';
    isLoading: boolean = false;

    constructor() {
        super();
    }

    async onLogin() {
        if (!this.email || !this.password) {
            alert('Por favor complete todos los campos');
            return;
        }

        this.set('isLoading', true);

        try {
            await authService.signIn(this.email, this.password);
            navigate({
                moduleName: 'views/profile/profile-page',
                clearHistory: true
            });
        } catch (error) {
            alert('Error al iniciar sesión: ' + error.message);
        } finally {
            this.set('isLoading', false);
        }
    }

    onSignUpTap() {
        navigate({
            moduleName: 'views/auth/register-page'
        });
    }
}