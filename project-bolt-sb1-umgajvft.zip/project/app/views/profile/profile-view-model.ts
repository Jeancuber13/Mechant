import { Observable } from '@nativescript/core';
import { Profile, Experience, Certificate, Bid } from '../../models/profile';
import { ProfileService } from '../../services/profile.service';
import { authService } from '../../services/auth.service';
import * as phone from '@nativescript/phone';
import { LocalNotifications } from '@nativescript/local-notifications';
import { navigate } from '@nativescript/core/ui/frame';

export class ProfileViewModel extends Observable {
    private profileService: ProfileService;
    private _profile: Profile;
    private _experiences: Experience[] = [];
    private _certificates: Certificate[] = [];
    private _bids: Bid[] = [];
    private _isLoading = false;

    constructor() {
        super();
        this.profileService = new ProfileService();
        
        if (!authService.isAuthenticated()) {
            navigate({
                moduleName: 'views/auth/login-page',
                clearHistory: true
            });
            return;
        }

        this.loadProfile();
        this.setupRealTimeSubscriptions();
    }

    async loadProfile() {
        try {
            this.set('isLoading', true);
            const userId = authService.currentUser?.id;
            if (!userId) throw new Error('Usuario no autenticado');

            const profileData = await this.profileService.getProfile(userId);
            this._profile = profileData;
            this._experiences = profileData.experiences || [];
            this._certificates = profileData.certificates || [];
            this._bids = profileData.bids || [];

            this.set('profile', this._profile);
            this.set('experiences', this._experiences);
            this.set('certificates', this._certificates);
            this.set('bids', this._bids);
        } catch (error) {
            console.error('Error loading profile:', error);
            alert('Error al cargar el perfil');
        } finally {
            this.set('isLoading', false);
        }
    }

    setupRealTimeSubscriptions() {
        const userId = authService.currentUser?.id;
        if (!userId) return;

        const subscription = supabase
            .channel('public:bids')
            .on('INSERT', payload => {
                if (payload.new.profileId === this._profile.id) {
                    this._bids.push(payload.new);
                    this.set('bids', [...this._bids]);
                    this.showBidNotification(payload.new);
                }
            })
            .subscribe();

        // Guardar la suscripción para limpiarla después
        this._subscription = subscription;
    }

    async showBidNotification(bid: Bid) {
        try {
            await LocalNotifications.schedule([{
                id: Date.now(),
                title: '¡Nueva oferta recibida!',
                body: `Has recibido una oferta de €${bid.amount}`,
                badge: 1
            }]);
        } catch (error) {
            console.error('Error showing notification:', error);
        }
    }

    onCall() {
        if (!this._profile?.phone) {
            alert('Número de teléfono no disponible');
            return;
        }

        try {
            phone.dial(this._profile.phone, true);
        } catch (error) {
            console.error('Error making call:', error);
            alert('Error al realizar la llamada');
        }
    }

    async onMakeBid() {
        if (!authService.isAuthenticated()) {
            alert('Debes iniciar sesión para hacer una oferta');
            return;
        }

        const amount = prompt('Ingrese su oferta:');
        if (!amount) return;

        const numAmount = parseFloat(amount);
        if (isNaN(numAmount) || numAmount <= 0) {
            alert('Por favor ingrese un monto válido');
            return;
        }

        try {
            await this.profileService.createBid({
                profileId: this._profile.id,
                bidderId: authService.currentUser.id,
                amount: numAmount,
                status: 'pending',
                message: 'Nueva oferta',
                createdAt: new Date()
            });
            alert('Oferta enviada con éxito');
        } catch (error) {
            console.error('Error creating bid:', error);
            alert('Error al enviar la oferta');
        }
    }

    async onAcceptBid(args) {
        const bid = args.object.bindingContext;
        try {
            await this.profileService.updateBid(bid.id, { status: 'accepted' });
            const bidIndex = this._bids.findIndex(b => b.id === bid.id);
            if (bidIndex !== -1) {
                this._bids[bidIndex] = { ...this._bids[bidIndex], status: 'accepted' };
                this.set('bids', [...this._bids]);
            }
            alert('Oferta aceptada');
        } catch (error) {
            console.error('Error accepting bid:', error);
            alert('Error al aceptar la oferta');
        }
    }

    async onRejectBid(args) {
        const bid = args.object.bindingContext;
        try {
            await this.profileService.updateBid(bid.id, { status: 'rejected' });
            const bidIndex = this._bids.findIndex(b => b.id === bid.id);
            if (bidIndex !== -1) {
                this._bids[bidIndex] = { ...this._bids[bidIndex], status: 'rejected' };
                this.set('bids', [...this._bids]);
            }
            alert('Oferta rechazada');
        } catch (error) {
            console.error('Error rejecting bid:', error);
            alert('Error al rechazar la oferta');
        }
    }

    onViewCertificate(args) {
        const certificate = args.object.bindingContext;
        if (!certificate?.documentUrl) {
            alert('Documento no disponible');
            return;
        }

        // Implementar visualización del certificado usando el visor de documentos nativo
    }

    // Limpiar recursos cuando se destruye el viewmodel
    destroy() {
        if (this._subscription) {
            this._subscription.unsubscribe();
        }
    }
}